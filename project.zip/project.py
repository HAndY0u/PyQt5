import sys
import sqlite3

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QPushButton, QLabel, QLineEdit, QTableWidgetItem


class StudentsDB(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('university.ui', self)  # Загружаем дизайн
        self.setWindowTitle("Ученики")  # задаем заголовок
        self.move(500, 100)  # перемещаем по экрану
        self.init_UI()

    def init_UI(self):
        self.pushButton.clicked.connect(self.zach)  # добавляем реакцию на нажатие кнопок
        self.pushButton_2.clicked.connect(self.otc)
        self.pushButton_3.clicked.connect(self.look)
        self.pushButton_4.clicked.connect(self.TDB)
        self.pushButton_5.clicked.connect(self.spravka)

        self.con = sqlite3.connect('daba.db')  # подключаем базу данных
        self.cur = self.con.cursor()
        res1 = self.cur.execute('''SELECT * FROM students''').fetchall()  # считываем данные из БД

        self.tableWidget.setRowCount(len(res1))  # выводим на экран значения
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))

    def zach(self):  # функция для добавления
        self.id = self.lineEdit.text()  # присваиваем значение переменным с полей ввода
        self.fam = self.lineEdit_2.text()
        self.nam = self.lineEdit_3.text()
        self.otch = self.lineEdit_4.text()
        self.kurs = self.lineEdit_5.text()
        self.cur = self.con.cursor()

        if self.id != '' and self.fam != '' and self.nam != '' and self.otch != '' and self.kurs != '':
            self.cur.execute("""INSERT INTO students VALUES (?, ?, ?, ?, ?)""",
                             (self.id, self.fam, self.nam, self.otch, self.kurs))  # добавление в БД
        else:
            self.wo = WindowOshibka()
            self.wo.show()

        res1 = self.cur.execute('''SELECT * FROM students''').fetchall()

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))
        self.con.commit()

    def otc(self):
        self.id = self.lineEdit.text()
        self.fam = self.lineEdit_2.text()
        self.nam = self.lineEdit_3.text()
        self.cur = self.con.cursor()

        if self.id != '' and self.nam != '' and self.fam != '':
            self.cur.execute("""DELETE FROM students WHERE id = ? and nam = ? and fam = ?""",
                             (self.id, self.nam, self.fam))  # удаление из БД
        else:
            self.wo = WindowOshibka()
            self.wo.show()

        res1 = self.cur.execute('''SELECT * FROM students''').fetchall()

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))
        self.con.commit()

    def look(self):
        self.id = self.lineEdit.text()

        usl = (self.id)
        self.cur = self.con.cursor()

        if self.id != '':
            res1 = self.cur.execute("""SELECT * FROM students WHERE id = ?""", usl).fetchall()  # показ определенного
        else:
            res1 = self.cur.execute('''SELECT * FROM students''').fetchall()  # показ всех

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))

    def spravka(self):
        self.w1 = Window1()
        self.w1.show()

    def TDB(self):
        self.db2 = TeachDB()
        self.db2.show()
        StudentsDB.close(self)


class TeachDB(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('universityTeachers.ui', self)
        self.setWindowTitle("Учителя")
        self.move(500, 100)
        self.init_UI()

    def init_UI(self):
        self.pushButton.clicked.connect(self.nan)
        self.pushButton_2.clicked.connect(self.fire)
        self.pushButton_3.clicked.connect(self.look)
        self.pushButton_4.clicked.connect(self.SDB)
        self.pushButton_5.clicked.connect(self.spravka)

        self.con = sqlite3.connect('daba.db')
        self.cur = self.con.cursor()
        res1 = self.cur.execute('''SELECT * FROM Teachers''').fetchall()

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))

    def nan(self):
        self.id = self.lineEdit.text()
        self.fam = self.lineEdit_2.text()
        self.nam = self.lineEdit_3.text()
        self.otch = self.lineEdit_4.text()
        self.cur = self.con.cursor()

        if self.id != '' and self.fam != '' and self.nam != '' and self.otch != '':
            self.cur.execute("""INSERT INTO Teachers VALUES (?, ?, ?, ?)""",
                             (int(self.id), self.fam, self.nam, self.otch))
        else:
            self.wo = WindowOshibka()
            self.wo.show()

        res1 = self.cur.execute('''SELECT * FROM Teachers''').fetchall()

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))
        self.con.commit()

    def fire(self):
        self.id = self.lineEdit.text()
        self.fam = self.lineEdit_2.text()
        self.nam = self.lineEdit_3.text()

        self.cur = self.con.cursor()
        if self.id != '' and self.nam != '' and self.fam != '':
            self.cur.execute("""DELETE from Teachers WHERE id = ? and name = ? and fam = ?""",
                             (self.id, self.nam, self.fam))
        else:
            self.wo = WindowOshibka()
            self.wo.show()

        res1 = self.cur.execute('''SELECT * FROM Teachers''').fetchall()

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))
        self.con.commit()

    def look(self):
        self.id = self.lineEdit.text()

        usl = (self.id)
        self.cur = self.con.cursor()

        if self.id != '':
            res1 = self.cur.execute("""SELECT * FROM Teachers where id = ?""", usl).fetchall()
        else:
            res1 = self.cur.execute('''SELECT * FROM Teachers''').fetchall()

        self.tableWidget.setRowCount(len(res1))
        for i, elem in enumerate(res1):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))

    def spravka(self):
        self.w2 = Window2()
        self.w2.show()

    def SDB(self):
        self.db1 = StudentsDB()
        self.db1.show()
        TeachDB.close(self)


class Window1(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('spravkaSDB.ui', self)
        self.setWindowTitle("Справка")
        self.move(50, 50)


class Window2(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('spravkaTDB.ui', self)
        self.setWindowTitle("Справка")
        self.move(50, 300)


class WindowOshibka(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('WindowOshibka.ui', self)
        self.setWindowTitle('Ошибка')
        self.setStyleSheet("background-color: rgb(200, 0, 0);")  # задаем цвет для фона


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = StudentsDB()
    ex.show()
    sys.exit(app.exec_())
